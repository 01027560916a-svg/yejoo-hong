# 홍예주 개인 브랜딩 랜딩페이지

차콜·아이보리·베이지 색상의 모던 테크 스타일로 제작한 반응형 개인 소개 웹사이트입니다.

## 파일 구성

- `index.html` — 웹사이트 메인 페이지
- `.nojekyll` — GitHub Pages의 Jekyll 처리를 비활성화
- `.gitignore` — 불필요한 로컬 파일 제외

## GitHub에 올리는 방법

1. GitHub에서 새 저장소(repository)를 만듭니다.
2. 저장소 이름을 예를 들어 `hong-yeju-portfolio`로 지정합니다.
3. 저장소를 공개(Public)로 설정합니다.
4. 이 폴더 안의 파일 4개를 저장소 최상위(root)에 업로드하고 커밋합니다.
5. 저장소의 **Settings → Pages**로 이동합니다.
6. **Build and deployment**에서 `Deploy from a branch`를 선택합니다.
7. Branch는 `main`, 폴더는 `/(root)`로 설정하고 저장합니다.
8. 배포가 완료되면 GitHub Pages가 표시하는 주소로 접속합니다.

## 수정하기

소개 문구, 활동 분야, 색상 등은 `index.html`에서 수정할 수 있습니다.
현재 페이지에는 개인 이메일이나 전화번호가 포함되어 있지 않습니다.
